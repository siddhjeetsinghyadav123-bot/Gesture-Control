package com.gesturecontrol.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout

/** Draws the air cursor and performs real taps / swipes / system actions in any app. */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureAccessibilityService? = null
        private const val STEP_MS = 30L
    }

    private lateinit var wm: WindowManager
    private var overlay: FrameLayout? = null
    private var dot: View? = null
    private var dotBg: GradientDrawable? = null
    private var dotR = 0f

    // continuous drag state
    private var dragActive = false
    private var dragBusy = false
    private var dragEnding = false
    private var dragStroke: GestureDescription.StrokeDescription? = null
    private var lastX = 0f
    private var lastY = 0f
    private var tgtX = 0f
    private var tgtY = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addOverlay()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        removeOverlay()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    @Suppress("DEPRECATION")
    fun screenSize(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    // ---------------- overlay cursor ----------------
    private fun addOverlay() {
        val density = resources.displayMetrics.density
        val size = (30 * density).toInt()
        dotR = size / 2f
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(200, 33, 150, 243))
            setStroke((2 * density).toInt(), Color.WHITE)
        }
        val v = View(this).apply { background = bg; visibility = View.GONE }
        val root = FrameLayout(this)
        root.addView(v, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        wm.addView(root, lp)
        overlay = root; dot = v; dotBg = bg
    }

    private fun removeOverlay() {
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null; dot = null; dotBg = null
    }

    fun showCursor(x: Float, y: Float, mode: CursorMode) {
        val d = dot ?: return
        d.visibility = View.VISIBLE
        d.translationX = x - dotR
        d.translationY = y - dotR
        val (color, scale) = when (mode) {
            CursorMode.MOVE -> Color.argb(200, 33, 150, 243) to 1f
            CursorMode.PRESS -> Color.argb(230, 76, 175, 80) to 0.7f
            CursorMode.DRAG -> Color.argb(230, 255, 152, 0) to 0.85f
        }
        dotBg?.setColor(color)
        d.scaleX = scale; d.scaleY = scale
    }

    fun hideCursor() { dot?.visibility = View.GONE }

    // ---------------- actions ----------------
    fun tap(x: Float, y: Float) {
        if (dragActive) return
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    fun global(g: GlobalGesture) {
        when (g) {
            GlobalGesture.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            GlobalGesture.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            GlobalGesture.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        }
    }

    // Live drag: a finger that stays down and keeps moving (chained strokes)
    fun dragStart(x: Float, y: Float) {
        dragReset()
        dragActive = true
        lastX = x; lastY = y; tgtX = x; tgtY = y
        dragStep()
    }

    fun dragMove(x: Float, y: Float) {
        if (!dragActive) return
        tgtX = x; tgtY = y
        if (!dragBusy) dragStep()
    }

    fun dragEnd() {
        if (!dragActive) return
        dragEnding = true
        if (!dragBusy) dragStep()
    }

    private fun dragReset() {
        dragActive = false; dragBusy = false; dragEnding = false; dragStroke = null
    }

    private fun dragStep() {
        if (!dragActive || dragBusy) return
        val path = Path().apply {
            moveTo(lastX, lastY)
            if (tgtX != lastX || tgtY != lastY) lineTo(tgtX, tgtY)
        }
        val finishing = dragEnding
        val stroke = dragStroke?.continueStroke(path, 0, STEP_MS, !finishing)
            ?: GestureDescription.StrokeDescription(path, 0, STEP_MS, !finishing)
        dragStroke = stroke
        lastX = tgtX; lastY = tgtY
        dragBusy = true
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    dragBusy = false
                    if (finishing) dragReset() else dragStep()
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    dragReset()
                }
            },
            null
        )
        if (!ok) dragReset()
    }
}
