package com.gesturecontrol.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Point
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Foreground service: front camera -> MediaPipe hand landmarks -> GestureEngine -> accessibility actions. */
class TrackingService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.gesturecontrol.app.STOP"
        private const val CHANNEL = "tracking"
        private const val TAG = "TrackingService"
        @Volatile var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var executor: ExecutorService
    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    @Volatile private var aspect = 0.75f
    private var lastTs = 0L

    private val sink = object : GestureSink {
        override fun onCursor(x: Float, y: Float, mode: CursorMode) {
            main.post { GestureAccessibilityService.instance?.showCursor(x, y, mode) }
        }
        override fun onHandLost() { main.post { GestureAccessibilityService.instance?.hideCursor() } }
        override fun onTap(x: Float, y: Float) { main.post { GestureAccessibilityService.instance?.tap(x, y) } }
        override fun onDragStart(x: Float, y: Float) { main.post { GestureAccessibilityService.instance?.dragStart(x, y) } }
        override fun onDragMove(x: Float, y: Float) { main.post { GestureAccessibilityService.instance?.dragMove(x, y) } }
        override fun onDragEnd() { main.post { GestureAccessibilityService.instance?.dragEnd() } }
        override fun onGlobal(g: GlobalGesture) { main.post { GestureAccessibilityService.instance?.global(g) } }
    }

    private lateinit var engine: GestureEngine

    override fun onCreate() {
        super.onCreate()
        executor = Executors.newSingleThreadExecutor()
        engine = GestureEngine(sink) {
            GestureAccessibilityService.instance?.screenSize()
                ?: Point(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundCompat()
        if (landmarker == null) {
            landmarker = buildLandmarker()
            startCamera()
        }
        running = true
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Gesture tracking", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, TrackingService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Gesture Control is on")
            .setContentText("Camera is processed on-device only")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    private fun build(delegate: Delegate): HandLandmarker {
        val base = BaseOptions.builder()
            .setModelAssetPath("hand_landmarker.task")
            .setDelegate(delegate)
            .build()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.6f)
            .setMinHandPresenceConfidence(0.6f)
            .setMinTrackingConfidence(0.6f)
            .setResultListener { result, _ -> onResult(result) }
            .setErrorListener { e -> Log.e(TAG, "MediaPipe error", e) }
            .build()
        return HandLandmarker.createFromOptions(this, opts)
    }

    private fun buildLandmarker(): HandLandmarker =
        try { build(Delegate.GPU) } catch (e: Exception) {
            Log.w(TAG, "GPU delegate failed, using CPU", e)
            build(Delegate.CPU)
        }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val p = future.get()
            provider = p
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        if (lm == null) { proxy.close(); return }
        try {
            val w = proxy.width
            val h = proxy.height
            val rot = proxy.imageInfo.rotationDegrees
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            proxy.use { bmp.copyPixelsFromBuffer(it.planes[0].buffer) }
            // rotate upright, then mirror so moving your hand right moves the cursor right
            val m = Matrix().apply { postRotate(rot.toFloat()); postScale(-1f, 1f) }
            val upright = Bitmap.createBitmap(bmp, 0, 0, w, h, m, true)
            aspect = upright.width.toFloat() / upright.height
            var ts = SystemClock.uptimeMillis()
            if (ts <= lastTs) ts = lastTs + 1
            lastTs = ts
            lm.detectAsync(BitmapImageBuilder(upright).build(), ts)
        } catch (e: Exception) {
            Log.e(TAG, "analyze failed", e)
        }
    }

    private fun onResult(result: HandLandmarkerResult) {
        val hands = result.landmarks()
        val t = SystemClock.uptimeMillis()
        if (hands.isEmpty()) {
            engine.onFrame(null, aspect, t)
        } else {
            val h = hands[0]
            val arr = FloatArray(42)
            for (i in 0 until 21) { arr[2 * i] = h[i].x(); arr[2 * i + 1] = h[i].y() }
            engine.onFrame(arr, aspect, t)
        }
    }

    override fun onDestroy() {
        running = false
        provider?.unbindAll()
        runCatching { landmarker?.close() }
        landmarker = null
        executor.shutdown()
        main.post {
            GestureAccessibilityService.instance?.dragEnd()
            GestureAccessibilityService.instance?.hideCursor()
        }
        super.onDestroy()
    }
}
