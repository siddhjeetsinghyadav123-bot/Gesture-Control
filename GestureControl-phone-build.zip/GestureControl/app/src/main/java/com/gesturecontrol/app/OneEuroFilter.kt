package com.gesturecontrol.app

import kotlin.math.PI
import kotlin.math.abs

/** 1-Euro filter: smooth when the hand is slow (no jitter), responsive when it moves fast (no lag). */
class OneEuroFilter(
    private val minCutoff: Double = 1.5,
    private val beta: Double = 0.012,
    private val dCutoff: Double = 1.0
) {
    private var xPrev = 0.0
    private var dxPrev = 0.0
    private var tPrev = 0L
    private var ready = false

    private fun alpha(cutoff: Double, dt: Double): Double {
        val tau = 1.0 / (2 * PI * cutoff)
        return 1.0 / (1.0 + tau / dt)
    }

    fun filter(x: Double, tMs: Long): Double {
        if (!ready) {
            ready = true; xPrev = x; dxPrev = 0.0; tPrev = tMs
            return x
        }
        val dt = ((tMs - tPrev) / 1000.0).coerceAtLeast(0.001)
        tPrev = tMs
        val dx = (x - xPrev) / dt
        val aD = alpha(dCutoff, dt)
        val dxHat = aD * dx + (1 - aD) * dxPrev
        val cutoff = minCutoff + beta * abs(dxHat)
        val a = alpha(cutoff, dt)
        val xHat = a * x + (1 - a) * xPrev
        xPrev = xHat
        dxPrev = dxHat
        return xHat
    }

    fun reset() { ready = false }
}
