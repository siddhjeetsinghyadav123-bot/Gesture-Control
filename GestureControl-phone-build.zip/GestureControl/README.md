# Gesture Control (Android)

Build the APK
1. Install Android Studio (latest). Open this folder (GestureControl).
2. Let Gradle sync (needs internet once: libraries + hand model download).
3. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk
4. Copy to phone, install.

First run on the phone
1. Open app > grant camera/notification permission.
2. Enable accessibility service "Gesture Control".
   Android 13+: if greyed out -> Settings > Apps > Gesture Control > ⋮ > Allow restricted settings.
3. Start gesture control. Put phone on a stand, hand ~30-50 cm from the front camera.

Tuning knobs: GestureEngine.kt companion object (PINCH_ON/OFF, X0..Y1, hold times).

## Build an APK using only a phone (GitHub Actions)

This project includes `.github/workflows/build-apk.yml`. You can use GitHub's website in your phone browser to upload the project files to a new repository, then open **Actions → Build Gesture Control APK → Run workflow**. When the run finishes, open the run and download the `GestureControl-debug-apk` artifact. Extract it and install `app-debug.apk` on your Android phone. The first build downloads the MediaPipe model, so the cloud build needs internet access.

This workflow creates a debug APK for testing, not a Play Store release. Android may ask you to allow installation from your browser or file manager.
