import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gesturecontrol.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gesturecontrol.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += "task" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Downloads the MediaPipe hand model into assets on first build (needs internet once).
val modelUrl = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
val modelFile = layout.projectDirectory.file("src/main/assets/hand_landmarker.task").asFile

tasks.register("downloadHandModel") {
    outputs.file(modelFile)
    doLast {
        if (!modelFile.exists() || modelFile.length() < 1000) {
            modelFile.parentFile.mkdirs()
            URL(modelUrl).openStream().use { input ->
                modelFile.outputStream().use { out -> input.copyTo(out) }
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("downloadHandModel") }
