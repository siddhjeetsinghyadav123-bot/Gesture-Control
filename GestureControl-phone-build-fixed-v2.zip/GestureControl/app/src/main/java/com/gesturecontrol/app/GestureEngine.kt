package com.gesturecontrol.app

import android.graphics.Point
import kotlin.math.hypot
import kotlin.math.min

enum class CursorMode { MOVE, PRESS, DRAG }
enum class GlobalGesture { BACK, HOME, RECENTS }

interface GestureSink {
    fun onCursor(x: Float, y: Float, mode: CursorMode)
    fun onHandLost()
    fun onTap(x: Float, y: Float)
    fun onDragStart(x: Float, y: Float)
    fun onDragMove(x: Float, y: Float)
    fun onDragEnd()
    fun onGlobal(g: GlobalGesture)
}

/**
 * Turns 21 hand landmarks per frame into cursor movement, taps, drags and system gestures.
 * Accuracy tricks: 1-Euro smoothing, pinch hysteresis + 2-frame confirmation,
 * click position taken from ~120 ms BEFORE the pinch (fingertip drifts while closing),
 * movement slop so taps never turn into accidental drags, stillness required for pose gestures.
 */
class GestureEngine(
    private val sink: GestureSink,
    private val screen: () -> Point
) {
    companion object {
        // Part of the camera frame that maps to the full screen (centre region = less arm reach)
        const val X0 = 0.20f; const val X1 = 0.80f
        const val Y0 = 0.15f; const val Y1 = 0.75f
        const val PINCH_ON = 0.30f      // thumb-index distance / hand size to start a pinch
        const val PINCH_OFF = 0.45f     // distance to release (hysteresis)
        const val LOOKBACK_MS = 120L
        const val HOLD_MS = 450L        // hold a pinch still this long = press-and-hold
        const val LOST_GRACE_MS = 250L  // tolerate brief tracking dropouts
        const val FIST_MS = 700L
        const val PALM_MS = 1200L
        const val THREE_MS = 900L
        const val GLOBAL_COOLDOWN_MS = 800L
    }

    private enum class State { IDLE, PRESSED, DRAGGING }
    private enum class Pose { NONE, FIST, PALM, THREE }
    private class Pt(val t: Long, val x: Float, val y: Float)

    private val fx = OneEuroFilter(1.5, 0.012)
    private val fy = OneEuroFilter(1.5, 0.012)
    private val history = ArrayDeque<Pt>()

    private var state = State.IDLE
    private var pinchFrames = 0
    private var releaseFrames = 0
    private var downT = 0L
    private var downX = 0f
    private var downY = 0f
    private var confX = 0f
    private var confY = 0f
    private var curX = 0f
    private var curY = 0f

    private var pose = Pose.NONE
    private var poseStartT = 0L
    private var poseFired = false
    private var poseWx = 0f
    private var poseWy = 0f
    private var lastGlobalT = 0L

    private var lastSeenT = 0L
    private var handVisible = false

    private fun dist(p: FloatArray, a: Int, b: Int, aspect: Float): Float =
        hypot((p[2 * a] - p[2 * b]) * aspect, p[2 * a + 1] - p[2 * b + 1])

    /** 2 = extended, 0 = curled, 1 = in between */
    private fun finger(p: FloatArray, mcp: Int, pip: Int, tip: Int, aspect: Float): Int {
        val tw = dist(p, tip, 0, aspect)
        val pw = dist(p, pip, 0, aspect)
        val mw = dist(p, mcp, 0, aspect)
        return when {
            tw > pw * 1.08f && tw > mw * 1.45f -> 2
            tw < mw * 1.2f -> 0
            else -> 1
        }
    }

    private fun pointAt(t: Long): Pt {
        for (i in history.indices.reversed()) if (history[i].t <= t) return history[i]
        return history.first()
    }

    private fun resetPose() { pose = Pose.NONE; poseFired = false }

    fun onFrame(p: FloatArray?, aspect: Float, t: Long) {
        if (p == null) { onLost(t); return }
        val size = dist(p, 0, 9, aspect)
        if (size < 0.03f) { onLost(t); return }

        if (!handVisible) {
            handVisible = true
            fx.reset(); fy.reset(); history.clear()
        }
        lastSeenT = t

        // ---- cursor (index fingertip), smoothed ----
        val s = screen()
        val rx = ((p[8] - X0) / (X1 - X0)).coerceIn(0f, 1f)
        val ry = ((p[9] - Y0) / (Y1 - Y0)).coerceIn(0f, 1f)
        curX = fx.filter((rx * (s.x - 1)).toDouble(), t).toFloat()
        curY = fy.filter((ry * (s.y - 1)).toDouble(), t).toFloat()
        history.addLast(Pt(t, curX, curY))
        while (history.size > 2 && t - history.first().t > 500) history.removeFirst()

        // ---- finger states ----
        val idx = finger(p, 5, 6, 8, aspect)
        val mid = finger(p, 9, 10, 12, aspect)
        val rng = finger(p, 13, 14, 16, aspect)
        val pnk = finger(p, 17, 18, 20, aspect)
        val allCurled = idx == 0 && mid == 0 && rng == 0 && pnk == 0
        val ratio = dist(p, 4, 8, aspect) / size
        val wantPinch = if (state == State.IDLE) (!allCurled && ratio < PINCH_ON) else ratio < PINCH_OFF
        val slop = 0.08f * min(s.x, s.y)

        // ---- pinch state machine ----
        when (state) {
            State.IDLE -> {
                pinchFrames = if (wantPinch) pinchFrames + 1 else 0
                if (pinchFrames >= 2) {
                    pinchFrames = 0; releaseFrames = 0
                    val o = pointAt(t - LOOKBACK_MS)
                    downX = o.x; downY = o.y; downT = t
                    confX = curX; confY = curY
                    state = State.PRESSED
                    resetPose()
                }
            }
            State.PRESSED -> {
                if (!wantPinch) {
                    releaseFrames++
                    if (releaseFrames >= 2) {
                        state = State.IDLE; releaseFrames = 0
                        sink.onTap(downX, downY)
                    }
                } else {
                    releaseFrames = 0
                    if (hypot(curX - confX, curY - confY) > slop || t - downT >= HOLD_MS) {
                        state = State.DRAGGING
                        sink.onDragStart(downX, downY)
                        sink.onDragMove(curX, curY)
                    }
                }
            }
            State.DRAGGING -> {
                if (!wantPinch) {
                    releaseFrames++
                    if (releaseFrames >= 2) {
                        state = State.IDLE; releaseFrames = 0
                        sink.onDragEnd()
                    }
                } else {
                    releaseFrames = 0
                    sink.onDragMove(curX, curY)
                }
            }
        }

        // ---- pose gestures (only when not pinching) ----
        if (state == State.IDLE) {
            val np = when {
                allCurled -> Pose.FIST
                idx == 2 && mid == 2 && rng == 2 && pnk == 2 -> Pose.PALM
                idx == 2 && mid == 2 && rng == 2 && pnk == 0 -> Pose.THREE
                else -> Pose.NONE
            }
            handlePose(np, p, t)
        }

        // ---- cursor feedback ----
        when (state) {
            State.IDLE -> sink.onCursor(curX, curY, CursorMode.MOVE)
            State.PRESSED -> sink.onCursor(downX, downY, CursorMode.PRESS)
            State.DRAGGING -> sink.onCursor(curX, curY, CursorMode.DRAG)
        }
    }

    private fun handlePose(np: Pose, p: FloatArray, t: Long) {
        if (np != pose) {
            pose = np; poseStartT = t; poseFired = false
            poseWx = p[0]; poseWy = p[1]
        }
        if (pose == Pose.NONE || poseFired) return
        // hand must stay still while holding the pose
        if (hypot(p[0] - poseWx, p[1] - poseWy) > 0.06f) {
            poseStartT = t; poseWx = p[0]; poseWy = p[1]
            return
        }
        val need = when (pose) {
            Pose.FIST -> FIST_MS
            Pose.PALM -> PALM_MS
            Pose.THREE -> THREE_MS
            Pose.NONE -> return
        }
        if (t - poseStartT >= need && t - lastGlobalT > GLOBAL_COOLDOWN_MS) {
            poseFired = true
            lastGlobalT = t
            sink.onGlobal(
                when (pose) {
                    Pose.FIST -> GlobalGesture.BACK
                    Pose.PALM -> GlobalGesture.HOME
                    else -> GlobalGesture.RECENTS
                }
            )
        }
    }

    private fun onLost(t: Long) {
        if (!handVisible) return
        if (t - lastSeenT < LOST_GRACE_MS) return
        handVisible = false
        if (state == State.DRAGGING) sink.onDragEnd()
        state = State.IDLE
        pinchFrames = 0; releaseFrames = 0
        resetPose()
        sink.onHandLost()
    }
}
