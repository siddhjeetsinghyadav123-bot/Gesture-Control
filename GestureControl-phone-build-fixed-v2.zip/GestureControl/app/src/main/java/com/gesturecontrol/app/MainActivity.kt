package com.gesturecontrol.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.camera.view.PreviewView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    companion object {
        @Volatile var previewView: PreviewView? = null
    }

    private lateinit var status: TextView
    private lateinit var toggle: Button

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(t: String, size: Float = 16f) = TextView(this).apply { text = t; textSize = size; setPadding(0, pad / 2, 0, pad / 2) }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply { text = t; setOnClickListener { onClick() } }

        root.addView(label("Gesture Control", 26f))
        root.addView(label("Live front-camera preview. Keep your hand visible in this frame."))
        val cameraPreview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        previewView = cameraPreview
        root.addView(cameraPreview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (260 * d).toInt()
        ))
        root.addView(label("Control your phone with hand gestures. Put the phone on a stand, front camera facing you."))
        status = label("")
        root.addView(status)
        root.addView(button("1. Grant camera & notification permission") {
            val perms = mutableListOf(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(perms.toTypedArray())
        })
        root.addView(button("2. Enable accessibility service") {
            Toast.makeText(this, "Open 'Gesture Control' and turn it on", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        toggle = button("3. Start gesture control") { toggleTracking() }
        root.addView(toggle)
        root.addView(label(
            "Gestures\n" +
                "• Point index finger: move cursor\n" +
                "• Pinch thumb + index: tap\n" +
                "• Pinch and move: scroll / swipe / drag\n" +
                "• Pinch and hold still: press-and-hold\n" +
                "• Fist (hold still 0.7s): Back\n" +
                "• Open palm (hold still 1.2s): Home\n" +
                "• 3 fingers up (hold still 0.9s): Recent apps", 14f))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        if (previewView?.context === this) previewView = null
        super.onDestroy()
    }

    private fun toggleTracking() {
        if (TrackingService.running) {
            startService(Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_STOP))
        } else {
            if (!hasCamera()) { Toast.makeText(this, "Grant camera permission first", Toast.LENGTH_SHORT).show(); return }
            if (GestureAccessibilityService.instance == null) { Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_SHORT).show(); return }
            ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java))
        }
        toggle.postDelayed({ refresh() }, 500)
    }

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun mark(b: Boolean) = if (b) "✓" else "✗"

    private fun refresh() {
        val run = TrackingService.running
        status.text = "Camera permission: ${mark(hasCamera())}\n" +
            "Accessibility service: ${mark(GestureAccessibilityService.instance != null)}\n" +
            "Tracking: ${if (run) "ON" else "OFF"}"
        toggle.text = if (run) "Stop gesture control" else "3. Start gesture control"
    }
}
